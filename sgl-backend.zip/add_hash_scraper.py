"""
Adiciona coluna hash_scraper na tabela editais.
Usado para detecção de duplicatas de scrapers.

Rodar:
    python add_hash_scraper.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dotenv import load_dotenv
load_dotenv()

from sgl.app import create_app
from sgl.models.database import db

app = create_app()

with app.app_context():
    try:
        # Verificar se coluna já existe
        result = db.session.execute(
            db.text("SELECT column_name FROM information_schema.columns WHERE table_name='editais' AND column_name='hash_scraper'")
        )
        if result.fetchone():
            print("✅ Coluna hash_scraper já existe")
        else:
            db.session.execute(
                db.text("ALTER TABLE editais ADD COLUMN hash_scraper VARCHAR(64)")
            )
            db.session.execute(
                db.text("CREATE INDEX ix_editais_hash_scraper ON editais (hash_scraper)")
            )
            db.session.commit()
            print("✅ Coluna hash_scraper adicionada com sucesso")
    except Exception as e:
        db.session.rollback()
        print(f"❌ Erro: {e}")
        # Pode ser que a tabela não exista ainda
        print("   Tentando via create_all...")
        try:
            db.create_all()
            print("✅ Tabelas criadas/atualizadas")
        except Exception as e2:
            print(f"❌ Erro fatal: {e2}")
