"""Aplica fixes no captacao_tasks.py e pncp_client.py"""

# Fix 1 - LogAtividade
print("Aplicando Fix 1 - LogAtividade...")
content = open('sgl/tasks/captacao_tasks.py', 'r', encoding='utf-8').read()

old_log = """            log = LogAtividade(
                tipo=tipo,
                descricao=f"Captação: {stats.get('novos_salvos', 0)} novos, {stats.get('duplicados', 0)} duplicados",
                dados_json=json.dumps(stats),
            )"""

new_log = """            log = LogAtividade(
                acao=tipo,
                entidade='edital',
                detalhes={
                    'stats': stats,
                    'novos': stats.get('novos_salvos', 0),
                    'duplicados': stats.get('duplicados', 0),
                },
            )"""

if old_log in content:
    content = content.replace(old_log, new_log)
    # Also remove unused json import in that function
    content = content.replace("        import json\n\n        with app.app_context():", "        with app.app_context():")
    open('sgl/tasks/captacao_tasks.py', 'w', encoding='utf-8').write(content)
    print("  ✅ Fix 1 OK - LogAtividade corrigido")
else:
    print("  ⚠️  Trecho não encontrado (já corrigido?)")

# Fix 2 - PNCP 422
print("Aplicando Fix 2 - PNCP 422...")
content2 = open('sgl/services/pncp_client.py', 'r', encoding='utf-8').read()

old_http = """        except requests.exceptions.HTTPError as e:
            logger.error(f"PNCP API HTTP Error: {e} | URL: {url} | Params: {params}")
            raise"""

new_http = """        except requests.exceptions.HTTPError as e:
            if response.status_code == 422:
                logger.warning(f"PNCP API 422 (sem dados): {params}")
                return []
            logger.error(f"PNCP API HTTP Error: {e} | URL: {url} | Params: {params}")
            raise"""

if old_http in content2:
    content2 = content2.replace(old_http, new_http)
    open('sgl/services/pncp_client.py', 'w', encoding='utf-8').write(content2)
    print("  ✅ Fix 2 OK - 422 tratado graciosamente")
else:
    print("  ⚠️  Trecho não encontrado (já corrigido?)")

print("\nDone! Reinicie o Worker (Ctrl+C e suba novamente).")
