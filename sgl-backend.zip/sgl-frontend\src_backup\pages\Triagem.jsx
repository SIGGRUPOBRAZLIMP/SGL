import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { getEditais, decidirTriagem } from '../services/api'
import { CheckCircle, XCircle, Eye, Filter, AlertCircle } from 'lucide-react'

export default function Triagem() {
  const [editais, setEditais] = useState([])
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    loadPendentes()
  }, [])

  const loadPendentes = async () => {
    setLoading(true)
    try {
      const r = await getEditais({ status: 'captado', per_page: 50 })
      setEditais(r.data.editais || [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleDecisao = async (editalId, decisao) => {
    setActionLoading(editalId)
    try {
      await decidirTriagem(editalId, { decisao, prioridade: 'media' })
      setEditais(prev => prev.filter(e => e.id !== editalId))
    } catch (err) {
      console.error(err)
    } finally {
      setActionLoading(null)
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Triagem</h1>
          <p className="text-gray-500">{editais.length} editais pendentes de avaliação</p>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary-600"></div>
        </div>
      ) : editais.length === 0 ? (
        <div className="card text-center py-12">
          <CheckCircle size={48} className="mx-auto text-success-500 mb-4" />
          <h3 className="text-lg font-medium text-gray-600 mb-2">Triagem em dia!</h3>
          <p className="text-gray-400">Todos os editais foram avaliados. Capture mais editais no PNCP.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {editais.map((e) => (
            <div key={e.id} className="card hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-gray-900">{e.orgao_razao_social}</h3>
                    {e.uf && <span className="badge bg-gray-100 text-gray-600">{e.uf}</span>}
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{e.objeto_resumo || 'Sem descrição do objeto'}</p>
                  <div className="flex flex-wrap gap-4 text-xs text-gray-400">
                    {e.modalidade_nome && <span>{e.modalidade_nome}</span>}
                    {e.data_publicacao && <span>Publicado: {new Date(e.data_publicacao).toLocaleDateString('pt-BR')}</span>}
                    {e.data_abertura_proposta && <span>Abertura: {new Date(e.data_abertura_proposta).toLocaleDateString('pt-BR')}</span>}
                  </div>
                </div>
                <div className="text-right ml-4">
                  {e.valor_estimado && (
                    <p className="text-lg font-bold text-primary-600 mb-2">
                      R$ {Number(e.valor_estimado).toLocaleString('pt-BR')}
                    </p>
                  )}
                  <div className="flex gap-2">
                    <button onClick={() => navigate(`/editais/${e.id}`)} className="btn-secondary text-xs py-1.5 px-3 flex items-center gap-1">
                      <Eye size={14} /> Ver
                    </button>
                    <button
                      onClick={() => handleDecisao(e.id, 'aprovado')}
                      disabled={actionLoading === e.id}
                      className="btn-success text-xs py-1.5 px-3 flex items-center gap-1 disabled:opacity-50"
                    >
                      <CheckCircle size={14} /> Aprovar
                    </button>
                    <button
                      onClick={() => handleDecisao(e.id, 'rejeitado')}
                      disabled={actionLoading === e.id}
                      className="btn-danger text-xs py-1.5 px-3 flex items-center gap-1 disabled:opacity-50"
                    >
                      <XCircle size={14} /> Rejeitar
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
