import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' }
})

// Interceptor para adicionar token JWT
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('sgl_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Interceptor para tratar 401 (token expirado)
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('sgl_token')
      localStorage.removeItem('sgl_user')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// Auth
export const login = (email, senha) => api.post('/auth/login', { email, senha })

// Dashboard
export const getDashboardStats = () => api.get('/dashboard/stats')

// Editais
export const getEditais = (params) => api.get('/editais', { params })
export const getEdital = (id) => api.get(`/editais/${id}`)
export const captarEditais = (data) => api.post('/editais/captar', data)
export const extrairItensAI = (id) => api.post(`/editais/${id}/extrair-itens`)
export const classificarEdital = (id, segmentos) => api.post(`/editais/${id}/classificar`, { segmentos })
export const resumirEdital = (id) => api.post(`/editais/${id}/resumir`)

// Triagem
export const getTriagem = (status = 'pendente') => api.get('/triagem', { params: { status } })
export const decidirTriagem = (editalId, data) => api.put(`/triagem/${editalId}`, data)

// Filtros
export const getFiltros = () => api.get('/filtros')
export const criarFiltro = (data) => api.post('/filtros', data)

// Fornecedores
export const getFornecedores = (busca) => api.get('/fornecedores', { params: { busca } })
export const criarFornecedor = (data) => api.post('/fornecedores', data)
export const atualizarFornecedor = (id, data) => api.put(`/fornecedores/${id}`, data)

// Processos
export const getProcessos = (params) => api.get('/processos', { params })
export const criarProcesso = (data) => api.post('/processos', data)
export const importarItensAI = (processoId) => api.post(`/processos/${processoId}/importar-itens-ai`)
export const analisarViabilidade = (processoId) => api.post(`/processos/${processoId}/analisar-viabilidade`)

export default api
