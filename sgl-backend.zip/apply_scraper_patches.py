"""
Aplica patches para integrar scrapers ao SGL:
1. Adiciona hash_scraper ao modelo Edital
2. Atualiza celery_app.py com tasks e schedule dos scrapers
3. Registra scraper_tasks no Celery include
"""

# ============================================
# Patch 1: Adicionar hash_scraper ao modelo
# ============================================
print("Patch 1: Adicionando hash_scraper ao modelo Edital...")

content = open('sgl/models/database.py', 'r', encoding='utf-8').read()

if 'hash_scraper' in content:
    print("  ✅ hash_scraper já existe no modelo")
else:
    # Encontrar onde adicionar (depois de plataforma_origem ou status)
    target = "plataforma_origem = db.Column(db.String(50)"
    if target in content:
        # Adicionar depois da linha plataforma_origem
        insert_after = content.find(target)
        # Ir até o final da linha
        end_of_line = content.find('\n', insert_after)
        content = (
            content[:end_of_line + 1] +
            "    hash_scraper = db.Column(db.String(64), index=True)  # Hash para dedup scrapers\n" +
            content[end_of_line + 1:]
        )
        open('sgl/models/database.py', 'w', encoding='utf-8').write(content)
        print("  ✅ hash_scraper adicionado ao modelo Edital")
    else:
        print("  ⚠️  Não encontrei 'plataforma_origem' no modelo. Adicione manualmente:")
        print("     hash_scraper = db.Column(db.String(64), index=True)")

# ============================================
# Patch 2: Atualizar celery_app.py
# ============================================
print("\nPatch 2: Atualizando celery_app.py com scrapers...")

content2 = open('sgl/celery_app.py', 'r', encoding='utf-8').read()

# 2a. Adicionar scraper_tasks ao include
if 'scraper_tasks' in content2:
    print("  ✅ scraper_tasks já está no include")
else:
    old_include = "include=['sgl.tasks.captacao_tasks']"
    new_include = "include=['sgl.tasks.captacao_tasks', 'sgl.tasks.scraper_tasks']"
    if old_include in content2:
        content2 = content2.replace(old_include, new_include)
        print("  ✅ scraper_tasks adicionado ao include")
    else:
        print("  ⚠️  Não encontrei include para atualizar")

# 2b. Adicionar schedule do scraping
if 'scraping-periodico' in content2:
    print("  ✅ Schedule de scraping já existe")
else:
    # Adicionar antes do fechamento do beat_schedule
    old_limpeza = """            # Limpeza de logs antigos (1x por semana, domingo 3h)
            'limpeza-semanal': {"""
    new_limpeza = """            # Scraping BLL + BNC + Licitanet (3x/dia)
            'scraping-periodico': {
                'task': 'sgl.tasks.scraper_tasks.scraping_automatico',
                'schedule': crontab(minute=30, hour='9,13,17'),
                'kwargs': {},
                'options': {'queue': 'scraping'},
            },

            # Limpeza de logs antigos (1x por semana, domingo 3h)
            'limpeza-semanal': {"""

    if old_limpeza in content2:
        content2 = content2.replace(old_limpeza, new_limpeza)
        print("  ✅ Schedule de scraping adicionado (9:30, 13:30, 17:30)")
    else:
        print("  ⚠️  Não encontrei local para inserir schedule")

# 2c. Adicionar rota de fila para scrapers
if 'scraper_tasks' in content2 and 'task_routes' in content2:
    old_routes_end = "        },"
    # Find the task_routes section
    routes_pos = content2.find("task_routes")
    if routes_pos > 0:
        # Find the closing brace of task_routes
        # Look for scraping route
        if 'scraping' not in content2[routes_pos:routes_pos+300]:
            old_default_route = "'sgl.tasks.captacao_tasks.limpeza_*': {'queue': 'default'},"
            new_default_route = "'sgl.tasks.captacao_tasks.limpeza_*': {'queue': 'default'},\n            'sgl.tasks.scraper_tasks.*': {'queue': 'scraping'},"
            if old_default_route in content2:
                content2 = content2.replace(old_default_route, new_default_route)
                print("  ✅ Rota de fila 'scraping' adicionada")
            else:
                print("  ⚠️  Não encontrei local para rota de fila")
        else:
            print("  ✅ Rota de fila 'scraping' já existe")

open('sgl/celery_app.py', 'w', encoding='utf-8').write(content2)

# ============================================
# Resumo
# ============================================
print("\n" + "=" * 50)
print("  Patches aplicados!")
print("=" * 50)
print("""
Próximos passos:
1. Rodar: python add_hash_scraper.py  (migração do banco)
2. Reiniciar Worker com fila 'scraping':
   celery -A sgl.celery_app:celery worker --pool=solo --loglevel=info -Q celery,captacao,ai,default,scraping
3. Reiniciar Beat
4. Testar: python -c "from sgl.services.scrapers import BLLScraper; print('OK')"
""")
