import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { getEditais } from '../services/api'
import { FileText, Search, ChevronLeft, ChevronRight, ExternalLink } from 'lucide-react'

export default function Editais() {
  const [editais, setEditais] = useState([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [busca, setBusca] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const navigate = useNavigate()
  const perPage = 15

  useEffect(() => {
    loadEditais()
  }, [page, statusFilter])

  const loadEditais = async () => {
    setLoading(true)
    try {
      const params = { page, per_page: perPage }
      if (statusFilter) params.status = statusFilter
      if (busca) params.busca = busca
      const r = await getEditais(params)
      setEditais(r.data.editais || [])
      setTotal(r.data.total || 0)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = (e) => {
    e.preventDefault()
    setPage(1)
    loadEditais()
  }

  const totalPages = Math.ceil(total / perPage)

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Editais</h1>
          <p className="text-gray-500">{total} editais no sistema</p>
        </div>
      </div>

      {/* Filtros */}
      <div className="card mb-6">
        <form onSubmit={handleSearch} className="flex flex-wrap gap-3 items-end">
          <div className="flex-1 min-w-[200px]">
            <label className="block text-sm font-medium text-gray-700 mb-1">Buscar</label>
            <div className="relative">
              <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
                className="input-field pl-10"
                placeholder="Órgão, objeto, número..."
              />
            </div>
          </div>
          <div className="w-40">
            <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
            <select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(1) }} className="input-field">
              <option value="">Todos</option>
              <option value="captado">Captado</option>
              <option value="aprovado">Aprovado</option>
              <option value="rejeitado">Rejeitado</option>
              <option value="em_processo">Em Processo</option>
            </select>
          </div>
          <button type="submit" className="btn-primary">Buscar</button>
        </form>
      </div>

      {/* Tabela */}
      <div className="card overflow-hidden p-0">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary-600"></div>
          </div>
        ) : editais.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <FileText size={48} className="mx-auto mb-3 opacity-50" />
            <p>Nenhum edital encontrado</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left py-3 px-4 text-gray-500 font-medium">ID</th>
                  <th className="text-left py-3 px-4 text-gray-500 font-medium">Órgão</th>
                  <th className="text-left py-3 px-4 text-gray-500 font-medium">Objeto</th>
                  <th className="text-left py-3 px-4 text-gray-500 font-medium">UF</th>
                  <th className="text-left py-3 px-4 text-gray-500 font-medium">Modalidade</th>
                  <th className="text-right py-3 px-4 text-gray-500 font-medium">Valor Est.</th>
                  <th className="text-left py-3 px-4 text-gray-500 font-medium">Status</th>
                  <th className="text-left py-3 px-4 text-gray-500 font-medium">Publicação</th>
                  <th className="py-3 px-4"></th>
                </tr>
              </thead>
              <tbody>
                {editais.map((e) => (
                  <tr key={e.id} className="border-t border-gray-100 hover:bg-gray-50 cursor-pointer" onClick={() => navigate(`/editais/${e.id}`)}>
                    <td className="py-3 px-4 text-gray-500">{e.id}</td>
                    <td className="py-3 px-4 font-medium text-gray-900 max-w-[200px] truncate">{e.orgao_razao_social}</td>
                    <td className="py-3 px-4 text-gray-600 max-w-[250px] truncate">{e.objeto_resumo || '—'}</td>
                    <td className="py-3 px-4 text-gray-600">{e.uf || '—'}</td>
                    <td className="py-3 px-4 text-gray-600">{e.modalidade_nome || '—'}</td>
                    <td className="py-3 px-4 text-right font-medium">
                      {e.valor_estimado ? `R$ ${Number(e.valor_estimado).toLocaleString('pt-BR')}` : '—'}
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge status={e.status} />
                    </td>
                    <td className="py-3 px-4 text-gray-400 text-xs">
                      {e.data_publicacao ? new Date(e.data_publicacao).toLocaleDateString('pt-BR') : '—'}
                    </td>
                    <td className="py-3 px-4">
                      <ExternalLink size={16} className="text-gray-400" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Paginação */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 bg-gray-50 border-t border-gray-100">
            <span className="text-sm text-gray-500">Página {page} de {totalPages}</span>
            <div className="flex gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn-secondary text-sm py-1 px-3 disabled:opacity-50">
                <ChevronLeft size={16} />
              </button>
              <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="btn-secondary text-sm py-1 px-3 disabled:opacity-50">
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function StatusBadge({ status }) {
  const styles = {
    captado: 'bg-blue-100 text-blue-700',
    aprovado: 'bg-green-100 text-green-700',
    rejeitado: 'bg-red-100 text-red-700',
    em_processo: 'bg-yellow-100 text-yellow-700',
  }
  return <span className={`badge ${styles[status] || 'bg-gray-100 text-gray-700'}`}>{status || 'captado'}</span>
}
